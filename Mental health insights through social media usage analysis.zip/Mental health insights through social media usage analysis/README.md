🧠 Mental Health Insights Through Social Media Usage Analysis
📌 Project Overview

This project explores the relationship between social media usage patterns and mental health status using data analysis and machine learning techniques. The study aims to identify behavioral factors that influence mental well-being and build a predictive model that can classify mental health status based on user activity data.

The project combines data preprocessing, exploratory data analysis (EDA), visualization, feature engineering, and machine learning to extract meaningful insights from the dataset.


Objectives

Analyze the impact of social media usage on mental health.
Identify the most influential factors affecting mental well-being.
Visualize patterns and trends within the dataset.
Build a machine learning model to predict mental health status.
Evaluate model performance and interpret results.

Dataset

The dataset contains information related to:

Daily social media usage hours
Sleep duration
Age
Social media addiction score
Other behavioral indicators
Mental health status (Target Variable)

 Technologies Used

Python
Pandas
NumPy
Matplotlib
Seaborn
Scikit-Learn
Jupyter Notebook

Data Preprocessing

The following preprocessing steps were performed:

Handling missing values
Removing duplicate records
Data cleaning and formatting
Feature selection
Train-test split


 Exploratory Data Analysis (EDA)

EDA was conducted to understand data distribution and relationships between variables.

Visualizations Included
Histograms
Box Plots
Correlation Heatmaps
Distribution Analysis
Feature Relationship Analysis
Key Insights
Social media usage shows a noticeable relationship with mental health outcomes.
Sleep duration appears to be an important factor influencing mental well-being.
Certain behavioral indicators contribute more significantly than others.


 Machine Learning Model
Algorithm Used

Random Forest Classifier

Random Forest was selected because it:

Handles complex relationships effectively
Reduces overfitting through ensemble learning
Provides feature importance analysis
Model Training
from sklearn.ensemble import RandomForestClassifier

model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)
Prediction
y_pred = model.predict(X_test)


 Model Evaluation

Evaluation metrics used:

Accuracy Score
Classification Report
Confusion Matrix
Result
Accuracy: 0.56

The model correctly predicts approximately 56% of the test samples.

Feature Importance

Feature importance analysis was performed to identify the variables that have the greatest influence on mental health prediction.

Example:

feature_importance = model.feature_importances_

This helps determine which behavioral factors contribute most significantly to mental health outcomes.

Project Structure
Mental-Health-Analysis/
│
├── dataset.csv
├── Mental_Health_Analysis.ipynb
├── requirements.txt
├── README.md
└── images/
    ├── heatmap.png
    ├── histogram.png
    └── confusion_matrix.png


How to Run the Project
Clone Repository
git clone https://github.com/yourusername/Mental-Health-Analysis.git
Navigate to Project Folder
cd Mental-Health-Analysis
Install Dependencies
pip install -r requirements.txt
Launch Jupyter Notebook
jupyter notebook

Open:

Mental_Health_Analysis.ipynb
Future Improvements
Hyperparameter tuning
Cross-validation
Handling class imbalance
Testing advanced models (XGBoost, LightGBM)
Streamlit web application deployment
Real-time prediction dashboard


Conclusion

This project demonstrates the application of data analysis and machine learning techniques to understand the relationship between social media behavior and mental health. The Random Forest model achieved an initial accuracy of 56%, providing a baseline for future improvements and more advanced predictive modeling.




Author

Ninumol C P

PhD Research Scholar (AI & ML)
M.Tech in Computer Science & Engineering
Master's Degree in Psychology


Research Interest

Emerging Trends in AI Paradigms for Mental Health Insight Generation Through Social Media Analysis